<?php
require_once "config.inc.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(isset($_POST["register"]) && isset($_FILES["profilePic"])){
        echo "<pre>";
        print_r($_FILES["profilePic"]);
        echo "</pre>";
    }
    else{
        header("Location: ../registration.php");
    }
    $profilePic = $_FILES["profilePic"]["name"];
    $profileTemp = $_FILES["profilePic"]["tmp_name"];
    $profileError = $_FILES["profilePic"]["error"];
    $profileSize = $_FILES["profilePic"]["size"];
    $email = $_POST["Email"];
    $password = $_POST["password"];
    $confpass = $_POST["confpass"];
    $Firstname = $_POST["Firstname"];
    $Lastname = $_POST["Lastname"];
    $Middlename = $_POST["Middlename"];
    $Suffix = $_POST["Suffix"];
    $Birthday = $_POST["Birthday"];
    $Address = $_POST["Address"];
    $ContactNo = $_POST["ContactNo"];

    $_SESSION['valid_values'] = [
        'email' => $email,
        'password' => $password,
        'confpass' => $confpass,
        'Firstname' => $Firstname,
        'Lastname' => $Lastname,
        'Middlename' => $Middlename,
        'Suffix' => $Suffix,
        'Birthday' => $Birthday,
        'Address' => $Address,
        'ContactNo' => $ContactNo,
    ];

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    

    if(empty($email)){
        $_SESSION['errors']['email'] = 'Email field is required.';
    } 

    if(empty($password)){
        $_SESSION['errors']['password'] = 'Password field is required.';
    } 

    if (empty($profilePic)) {
        $_SESSION['errors']['profilePic'] = 'Profile picture is required.';
    } else {
        if ($profileError === 0) {
            if($profileSize > 125000) {
                $error_message = "Sorry, your file is too large";
                header("Location: ../registration.php?error=$error_message");
            } else{
                $extension = pathinfo($profilePic, PATHINFO_EXTENSION);
                $extensionLower = strtolower($extension);                
                $allowedExtension = array("jpg", "jpeg", "png");
                if(in_array($extensionLower, $allowedExtension)) {
                    $image = uniqid("IMG-", true). '.'. $extensionLower;
                    $path = "../profilepictures/" . $image;
                    move_uploaded_file($profileTemp, $path);
                }else{
                    $error_message = "You can't upload files of this type";
                    header("Location: ../registration.php?error=$error_message");
                }
            }
        } 
    }

    if(empty($confpass)){
        $_SESSION['errors']['confpass'] = 'Confirm password field is required.';
    } 

    if(empty($Firstname)){
        $_SESSION['errors']['Firstname'] = 'Firstname field is required.';
    } 

    if(empty($Lastname)){
        $_SESSION['errors']['Lastname'] = 'Lastname field is required.';
    } 

    if(empty($Middlename)){
        $_SESSION['errors']['Middlename'] = 'Middlename field is required.';
    } 

    if(empty($Suffix)){
        $_SESSION['errors']['Suffix'] = 'Suffix field is required.';
    } 

    if(empty($Birthday)){
        $_SESSION['errors']['Birthday'] = 'Birthday field is required.';
    } 

    if(empty($Address)){
        $_SESSION['errors']['Address'] = 'Address field is required.';
    } 

    if(empty($ContactNo)){
        $_SESSION['errors']['ContactNo'] = 'Contact Number field is required.';
    } 

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['errors']['email'] = 'Invalid email address format.';
        $_SESSION['valid_values']['email'] = '';
    } 

    if(isset($_POST["register"]) && isset($_FILES["profilePic"])){
        echo "<pre>";
        print_r($_FILES["profilePic"]);
        echo "</pre>";
    }
    else{
        header("Location: ../registration.php");
    }

    if(isset($_SESSION['errors'])) {
        header("Location: ../registration.php");
        
        exit();
    }

    try{
        require_once "dbc.inc.php";
        $query = "INSERT INTO registration (EMAIL, PASSWORD, PROFILEPICTURE, FIRSTNAME, LASTNAME, MIDDLENAME, SUFFIX, BIRTHDAY, ADDRESS, CONTACTNO) 
              VALUES (:email, :password, :profilePic, :firstname, :lastname, :middlename, :suffix, :birthday, :address, :contactNo)";
    
    
        $stmt = $pdo->prepare($query);

        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $passwordHash);
        $stmt->bindParam(':profilePic', $image);
        $stmt->bindParam(':firstname', $Firstname);
        $stmt->bindParam(':lastname', $Lastname);
        $stmt->bindParam(':middlename', $Middlename);
        $stmt->bindParam(':suffix', $Suffix);
        $stmt->bindParam(':birthday', $Birthday);
        $stmt->bindParam(':address', $Address);
        $stmt->bindParam(':contactNo', $ContactNo);

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        header("Location: ../registration.php");
    }
    catch(PDOException $e){
        die("Query failed: " . $e->getMessage());
    }
} else{
    header("Location: ../registration.php");
}
