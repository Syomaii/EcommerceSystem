<?php
require_once 'config.inc.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["Email"];
    $password = $_POST["password"];

    if (empty($email) || empty($password)) {
        echo "Invalid email or password";
    } else {
        try {
            require_once "dbc.inc.php";

            $query = "SELECT * FROM registration WHERE EMAIL = :email;";

            $stmt = $pdo->prepare($query);

            $stmt->bindParam(":email", $email);

            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            echo "<pre>";
            print_r($result);
            echo "</pre>";

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            if ($result) {
                $passwordHash = $result['PASSWORD'];
                if (password_verify($password, $result['PASSWORD'])) {
                    $pdo = null;
                    $stmt = null;

                    header("Location: ../registration.php");
                    die();
                } else {
                    $_SESSION['errors']['email'] = "Invalid Password";
                }
            } else {
                $_SESSION['errors']['email'] = "Invalid Email";
            }
        } catch (PDOException $e) {
            die("Query failed: " . $e->getMessage());
        }
    }
} else {
    header("Location: ../index.php");
}