<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/registration.style.css">
    <title>Login</title>
</head>
<body>
<section>
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-8 col-md-6 m-auto">
                    <div class="box card border-0 shadow mt-5 ">
                        <div class="card-body">
                        <h1 class="text-center mb-2">Login</h2>
                            <form action="includes/login.inc.php" method="post" enctype="multipart/form-data">
                                <!--Email-->
                                <div>
                                    <input type="text" name="Email" id="" class="form-control my-4 py-2" placeholder="Email" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['email'] ) : ''; ?>" <?= isset($_SESSION['errors']['email']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['email']) ? $_SESSION['errors']['email'] : '' ?>
                                </div>
                               
                                <!--Password-->
                                <div class="input-group my-4">
                                    <input type="password" name="password" class="form-control py-2" placeholder="Password" id="pwd" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['password'] ) : ''; ?>" <?= isset($_SESSION['errors']['password']) ? 'style="border: 1px solid red;"' : 'red' ?>/>

                                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
                                        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
                                        </svg>
                                    </button>
                                </div>
                                <?= isset($_SESSION['errors']['password']) ? $_SESSION['errors']['password'] : '' ?>

                                <div class="text-center">
                                    <div class="mb-3">
                                        <input type="submit" class="btn btn-primary" name="register" value="Login"></input>
                                    </div>
                                    <div class="d-inline">
                                        <p class="d-inline">Don't have an account?</p>
                                        <a href="registration.php" class="nav-link d-inline">Sign-up</a>
                                    </div>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
        unset($_SESSION['errors']);
        unset($_SESSION['valid_values']);
    ?>
    </section>
    
    <script src="scripts/registration.script.js"></script>
</body>
</html>