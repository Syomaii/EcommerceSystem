<?php
    require_once 'includes/config.inc.php';
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/registration.style.css">
    <title>Registration</title>
</head>
<body>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-8 col-md-6 m-auto">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                        <h1 class="text-center mb-2">Registration</h2>
                            <form action="includes/registration.inc.php" method="post" enctype="multipart/form-data">

                                <!--Profile Picture-->
                                <div class="form-group text-center"     onclick="triggerClick()">
                                    <div id="profileDisplay" class="rounded-circle overflow-hidden">
                                        <img src="images/placeholder.png" id="profileImage" class="w-100 h-100" alt="Profile Picture">
                                    </div>
                                    <h3 class="text-center">Profile Picture</h3>
                                    <input type="file" name="profilePic" id="profilePic" onchange="displayImage(this)" <?= isset($_SESSION['errors']['profilePic']) ? 'style="border: 1px solid red;"' : 'red' ?> style=""/>
                                    <?= isset($_SESSION['errors']['profilePic']) ? $_SESSION['errors']['profilePic'] : '' ?>
                                </div>


                                <!--Email-->
                                <div>
                                    <input type="text" name="Email" id="" class="form-control my-4 py-2" placeholder="Email" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['email'] ) : ''; ?>" <?= isset($_SESSION['errors']['email']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['email']) ? $_SESSION['errors']['email'] : '' ?>
                                </div>
                               
                                <!--Password-->
                                <div class="input-group my-4">
                                    <input type="password" name="password" class="form-control py-2" placeholder="Password" id="pwd" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['password'] ) : ''; ?>" <?= isset($_SESSION['errors']['password']) ? 'style="border: 1px solid red;"' : 'red' ?>/>

                                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
                                        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
                                        </svg>
                                    </button>
                                </div>
                                <?= isset($_SESSION['errors']['password']) ? $_SESSION['errors']['password'] : '' ?>

                                <!--Confirm Password-->
                                <div class="input-group my-4">
                                    <input type="password" name="confpass"class="form-control py-2" placeholder="Confirm Password" id="confPwd" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['confpass'] ) : ''; ?>" <?= isset($_SESSION['errors']['confpass']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    
                                    <button class="btn btn-outline-secondary" type="button" id="toggleConfPassword">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
                                        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
                                        </svg>
                                    </button>
                                </div>
                                <?= isset($_SESSION['errors']['confpass']) ? $_SESSION['errors']['confpass'] : '' ?>

                                <!--Firstname-->
                                <div>
                                    <input type="text" name="Firstname" id="Firstname" class="form-control my-4 py-2" placeholder="Firstname" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Firstname'] ) : ''; ?>" <?= isset($_SESSION['errors']['Firstname']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Firstname']) ? $_SESSION['errors']['Firstname'] : '' ?>
                                </div>
                                
                                <!--Lastname-->
                                <div>
                                    <input type="text" name="Lastname" id="Lastname" class="form-control my-4 py-2" placeholder="Lastname" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Lastname'] ) : ''; ?>" <?= isset($_SESSION['errors']['Lastname']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Lastname']) ? $_SESSION['errors']['Lastname'] : '' ?>
                                </div>
                                
                                <!--Middlename-->
                                <div>
                                    <input type="text" name="Middlename" id="Middlename" class="form-control my-4 py-2" placeholder="Middlename" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Middlename'] ) : ''; ?>" <?= isset($_SESSION['errors']['Middlename']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Middlename']) ? $_SESSION['errors']['Middlename'] : '' ?>
                                </div>
                                
                                <!--Suffix-->
                                <div>
                                    <input type="text" name="Suffix" id="Suffix" class="form-control my-4 py-2" placeholder="Suffix" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Suffix'] ) : ''; ?>" <?= isset($_SESSION['errors']['Suffix']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Suffix']) ? $_SESSION['errors']['Suffix'] : '' ?>
                                </div>
                                
                                <!--Birthday--> 
                                <div>
                                    <input type="date" name="Birthday" id="Birthday" class="form-control my-4 py-2" placeholder="Birthday" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Birthday'] ) : ''; ?>" <?= isset($_SESSION['errors']['Birthday']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Birthday']) ? $_SESSION['errors']['Birthday'] : '' ?>
                                </div>
                                
                                <!--Address-->
                                <div>
                                    <input type="text" name="Address" id="Address" class="form-control my-4 py-2" placeholder="Address" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['Address'] ) : ''; ?>" <?= isset($_SESSION['errors']['Address']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['Address']) ? $_SESSION['errors']['Address'] : '' ?>
                                </div>
                                
                                <!--Contact number-->
                                <div>
                                    <input type="text" name="ContactNo" id="ContactNo" class="form-control my-4 py-2" placeholder="Contact Number" value="<?= isset($_SESSION['valid_values']) ? htmlspecialchars($_SESSION['valid_values']['ContactNo'] ) : ''; ?>" <?= isset($_SESSION['errors']['ContactNo']) ? 'style="border: 1px solid red;"' : 'red' ?>/>
                                    <?= isset($_SESSION['errors']['ContactNo']) ? $_SESSION['errors']['ContactNo'] : '' ?>
                                </div>
                                
                                <div class="text-center">
                                    <div class="mb-3">
                                        <input type="submit" class="btn btn-primary" name="register" value="Register"></input>
                                    </div>
                                    <div class="d-inline">
                                        <p class="d-inline">Already have an account?</p>
                                        <a href="login.php" class="nav-link d-inline">Login</a>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
        unset($_SESSION['errors']);
        unset($_SESSION['valid_values']);
    ?>
    </section>
    
    <script src="scripts/registration.script.js"></script>

</body>
</html>